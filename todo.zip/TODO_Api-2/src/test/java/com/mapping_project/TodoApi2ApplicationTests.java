package com.mapping_project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TodoApi2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
