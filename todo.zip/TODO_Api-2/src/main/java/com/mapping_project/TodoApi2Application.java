package com.mapping_project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages = "com.mapping_project")
public class TodoApi2Application {

	public static void main(String[] args) {
		SpringApplication.run(TodoApi2Application.class, args);
	}

}
