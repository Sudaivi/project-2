package com.mapping_project.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Entity
@Table(name="task")
@NoArgsConstructor
@Getter
@Setter

public class Task {

		@Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
		private Long id;
		
		@NotBlank(message = "Title cannot be blank")
	    @Size(min = 3, max = 255, message = "Title must be between 3 and 255 characters")
	    private String title;
	    private boolean completed;


}


