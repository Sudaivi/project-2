package com.mapping_project.service;

import java.util.List;

import com.mapping_project.entity.Task;

public interface TaskService {

	List<Task> getAllTasks();
    Task createTask(Task task);
    Task getTaskById(Long id);
    Task updateTask(Long id, Task updatedTask);
    void deleteTask(Long id);
}
